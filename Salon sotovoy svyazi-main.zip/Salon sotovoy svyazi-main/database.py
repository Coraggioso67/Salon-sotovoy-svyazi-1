import sqlite3
import hashlib
from datetime import datetime
import os
import ctypes

class Database:
    # Изменили расширение на .sqlite3, чтобы Windows не ставила шестерёнку
    def __init__(self, db_path="sputnik_service.sqlite3"):
        self.db_path = db_path
        
    def connect(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_db(self):
        conn = self.connect()
        cursor = conn.cursor()
        
        # Таблица клиентов
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                phone TEXT,
                client_type TEXT DEFAULT 'Новый',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица товаров
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                price REAL NOT NULL
            )
        ''')
        
        # Таблица операций/продаж салона связи
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT CHECK(type IN ('sale', 'activation', 'payment')),
                client_id INTEGER,
                product_id INTEGER,
                phone_number TEXT,
                tariff_name TEXT,
                amount REAL DEFAULT 0,
                user_id INTEGER,
                coupon TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
            )
        ''')
        
        # Таблица пользователей (Персонал)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT CHECK(role IN ('admin', 'cashier', 'manager')) DEFAULT 'cashier',
                full_name TEXT
            )
        ''')
        
        # Создание пользователей по умолчанию
        users = [
            ("admin", "admin", "admin", "Главный администратор"),
            ("cashier", "cashier", "cashier", "Кассир Иван"),
            ("manager", "manager", "manager", "Менеджер Анна")
        ]
        
        for username, password, role, full_name in users:
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            cursor.execute('''
                INSERT OR IGNORE INTO users (username, password_hash, role, full_name)
                VALUES (?, ?, ?, ?)
            ''', (username, password_hash, role, full_name))
        
        # Добавление товаров салона связи по умолчанию
        products_init = [
            ("Смартфон Sputnik Pro", 19990),
            ("Зарядное устройство Type-C", 990),
            ("Защитное стекло", 490),
            ("Беспроводные наушники", 2990),
            ("Чехол силиконовый универсальный", 390)
        ]
        
        for name, price in products_init:
            cursor.execute('INSERT OR IGNORE INTO products (name, price) VALUES (?, ?)', (name, price))
        
        # Тестовые клиенты
        cursor.execute('''
            INSERT OR IGNORE INTO clients (id, full_name, phone, client_type)
            VALUES 
                (1, 'Иванов Иван Иванович', '+7(999)123-45-67', 'Постоянный'),
                (2, 'Петрова Анна Сергеевна', '+7(999)987-65-43', 'Новый'),
                (3, 'Сидоров Петр Алексеевич', '+7(999)555-55-55', 'VIP')
        ''')
        
        conn.commit()
        conn.close()
        
        # Магия скрытия: делаем созданный файл невидимым для Windows
        try:
            ctypes.windll.kernel32.SetFileAttributesW(self.db_path, 2) 
        except Exception:
            pass


class ClientModel:
    def __init__(self, db):
        self.db = db
        
    def get_all(self):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM clients ORDER BY full_name')
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def add(self, full_name, phone, client_type):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO clients (full_name, phone, client_type) VALUES (?, ?, ?)',
                      (full_name, phone, client_type))
        conn.commit()
        client_id = cursor.lastrowid
        conn.close()
        return client_id
    
    def delete(self, client_id):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM clients WHERE id = ?', (client_id,))
        conn.commit()
        conn.close()


class ProductModel:
    def __init__(self, db):
        self.db = db
        
    def get_all(self):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM products ORDER BY name')
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def add(self, name, price):
        conn = self.db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO products (name, price) VALUES (?, ?)', (name, price))
            conn.commit()
            product_id = cursor.lastrowid
            conn.close()
            return product_id
        except sqlite3.IntegrityError:
            conn.close()
            return None
    
    def update(self, product_id, name, price):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('UPDATE products SET name = ?, price = ? WHERE id = ?', (name, price, product_id))
        conn.commit()
        conn.close()
    
    def delete(self, product_id):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM products WHERE id = ?', (product_id,))
        conn.commit()
        conn.close()


class SaleModel:
    def __init__(self, db):
        self.db = db
        
    def add_sale(self, client_id, product_id, amount, user_id, coupon):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO sales (type, client_id, product_id, amount, user_id, coupon)
            VALUES ('sale', ?, ?, ?, ?, ?)
        ''', (client_id, product_id, amount, user_id, coupon))
        conn.commit()
        sale_id = cursor.lastrowid
        conn.close()
        return sale_id
    
    def add_activation(self, client_id, phone_number, tariff_name, user_id):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO sales (type, client_id, phone_number, tariff_name, amount, user_id)
            VALUES ('activation', ?, ?, ?, 0, ?)
        ''', (client_id, phone_number, tariff_name, user_id))
        conn.commit()
        sale_id = cursor.lastrowid
        conn.close()
        return sale_id
    
    def add_direct_payment(self, client_id, amount, user_id):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO sales (type, client_id, amount, user_id)
            VALUES ('payment', ?, ?, ?)
        ''', (client_id, amount, user_id))
        conn.commit()
        sale_id = cursor.lastrowid
        conn.close()
        return sale_id
    
    def get_all(self):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT s.*, c.full_name as client_name, p.name as product_name, u.username as user_name
            FROM sales s
            LEFT JOIN clients c ON s.client_id = c.id
            LEFT JOIN products p ON s.product_id = p.id
            LEFT JOIN users u ON s.user_id = u.id
            ORDER BY s.timestamp DESC
        ''')
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def get_by_period(self, date_from, date_to):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT s.*, c.full_name as client_name, p.name as product_name, u.username as user_name
            FROM sales s
            LEFT JOIN clients c ON s.client_id = c.id
            LEFT JOIN products p ON s.product_id = p.id
            LEFT JOIN users u ON s.user_id = u.id
            WHERE date(s.timestamp) BETWEEN date(?) AND date(?)
            ORDER BY s.timestamp DESC
        ''', (date_from, date_to))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def get_revenue_by_period(self, date_from, date_to):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT SUM(amount) as total FROM sales 
            WHERE type IN ('sale', 'payment') AND date(timestamp) BETWEEN date(?) AND date(?)
        ''', (date_from, date_to))
        row = cursor.fetchone()
        conn.close()
        return row['total'] if row['total'] else 0


class UserModel:
    def __init__(self, db):
        self.db = db
        
    def authenticate(self, username, password):
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ? AND password_hash = ?', (username, password_hash))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    
    def get_all(self):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, role, full_name FROM users')
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]
    
    def add(self, username, password, role, full_name):
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        conn = self.db.connect()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO users (username, password_hash, role, full_name)
                VALUES (?, ?, ?, ?)
            ''', (username, password_hash, role, full_name))
            conn.commit()
            success = True
        except sqlite3.IntegrityError:
            success = False
        conn.close()
        return success
    
    def delete(self, user_id):
        conn = self.db.connect()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM users WHERE id = ? AND username != "admin"', (user_id,))
        conn.commit()
        conn.close()


# Автозапуск создания невидимой базы данных
if __name__ == '__main__':
    print("Запуск генерации базы данных...")
    db_instance = Database()
    db_instance.init_db()
    print("\n[ГОТОВО] База данных успешно создана!")
    print("Проверь папку проекта — файла базы данных там НЕ видно, но он работает в скрытом режиме.")
