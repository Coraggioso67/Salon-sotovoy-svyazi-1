from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from database import Database, ClientModel, ProductModel, SaleModel, UserModel
from datetime import datetime, timedelta
import json

app = Flask(__name__)
app.secret_key = 'sputnik_service_secret_key_2026'

# Инициализация БД салона связи
db = Database()
db.init_db()

# Модели информационной системы
client_model = ClientModel(db)
product_model = ProductModel(db)
sale_model = SaleModel(db)
user_model = UserModel(db)


# ==================== ДЕКОРАТОРЫ ДЛЯ ПРОВЕРКИ ДОСТУПА ====================

def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

def role_required(roles):
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'user_role' not in session or session['user_role'] not in roles:
                return "Доступ запрещён (Требуются права администратора)", 403
            return f(*args, **kwargs)  # ИСПРАВЛЕНО: отступ перенесен внутрь wrapper
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator


# ==================== СТРАНИЦЫ АВТОРИЗАЦИИ И ПАНЕЛИ ====================

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = user_model.authenticate(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['user_role'] = user['role']
            session['user_full_name'] = user.get('full_name', username)
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Неверный логин или пароль сотрудника')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    sales_operations = sale_model.get_all()
    total_clients = len(client_model.get_all())
    total_products = len(product_model.get_all())
    
    payments = [op for op in sales_operations if op['type'] in ['sale', 'payment']]
    total_revenue = sum(op['amount'] for op in payments)
    
    return render_template('index.html', 
                          user=session,
                          total_clients=total_clients,
                          total_products=total_products,
                          total_revenue=total_revenue)


# ==================== КЛИЕНТЫ И БАЗА АБОНЕНТОВ ====================

@app.route('/clients')
@login_required
def clients():
    clients_list = client_model.get_all()
    return render_template('clients.html', clients=clients_list, user=session)

@app.route('/clients/add', methods=['POST'])
@login_required
def add_client():
    data = request.get_json()
    full_name = data.get('full_name')
    phone = data.get('phone', '')
    client_type = data.get('client_type', 'Новый')
    
    if full_name:
        client_id = client_model.add(full_name, phone, client_type)
        return jsonify({'success': True, 'id': client_id})
    return jsonify({'success': False, 'error': 'ФИО клиента обязательно для заполнения'})

@app.route('/clients/delete/<int:client_id>', methods=['DELETE'])
@login_required
def delete_client(client_id):
    client_model.delete(client_id)
    return jsonify({'success': True})


# ==================== ТОВАРЫ И АССОРТИМЕНТ (СКЛАД) ====================

@app.route('/products')
@login_required
def products():
    products_list = product_model.get_all()
    return render_template('products_admin.html', products=products_list, user=session)

@app.route('/products/add', methods=['POST'])
@login_required
def add_product():
    data = request.get_json()
    name = data.get('name')
    price = data.get('price')
    
    if name and price:
        product_id = product_model.add(name, price)
        if product_id:
            return jsonify({'success': True, 'id': product_id})
    return jsonify({'success': False, 'error': 'Ошибка добавления товара в номенклатуру'})

@app.route('/products/update/<int:product_id>', methods=['PUT'])
@login_required
def update_product(product_id):
    data = request.get_json()
    name = data.get('name')
    price = data.get('price')
    
    if name and price:
        product_model.update(product_id, name, price)
        return jsonify({'success': True})
    return jsonify({'success': False})

@app.route('/products/delete/<int:product_id>', methods=['DELETE'])
@login_required
def delete_product(product_id):
    product_model.delete(product_id)
    return jsonify({'success': True})


# ==================== ПОЛЬЗОВАТЕЛИ (ПЕРСОНАЛ САЛОНА) ====================

@app.route('/users')
@login_required
@role_required(['admin'])
def users():
    users_list = user_model.get_all()
    return render_template('users_admin.html', users=users_list, user=session)

@app.route('/users/add', methods=['POST'])
@login_required
@role_required(['admin'])
def add_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')
    full_name = data.get('full_name', '')
    
    if username and password and role:
        success = user_model.add(username, password, role, full_name)
        return jsonify({'success': success})
    return jsonify({'success': False})

@app.route('/users/delete/<int:user_id>', methods=['DELETE'])
@login_required
@role_required(['admin'])
def delete_user(user_id):
    user_model.delete(user_id)
    return jsonify({'success': True})


# ==================== ОПЕРАЦИИ И КАССОВЫЙ МОДУЛЬ ====================

@app.route('/sale_form')
@login_required
def sale_form():
    clients = client_model.get_all()
    products = product_model.get_all()
    return render_template('sale.html', clients=clients, products=products, user=session)

@app.route('/api/sale/process', methods=['POST'])
@login_required
def process_sale():
    data = request.get_json()
    client_id = data.get('client_id')
    product_id = data.get('product_id')
    coupon = data.get('coupon', '')
    discount_pct = data.get('discount_pct', 0)
    
    if not client_id or not product_id:
        return jsonify({'success': False, 'error': 'Выберите клиента и хотя бы один товар'})
    
    products = product_model.get_all()
    product = next((p for p in products if p['id'] == product_id), None)
    if not product:
        return jsonify({'success': False, 'error': 'Товар не найден на складе'})
    
    base_amount = product['price']
    discount_amount = base_amount * (float(discount_pct) / 100.0)
    
    if coupon.upper() == "PROMO2026":
        discount_amount += 500  
        
    final_amount = max(0, base_amount - discount_amount)
    
    sale_model.add_sale(client_id, product_id, final_amount, session['user_id'], coupon)
    
    return jsonify({
        'success': True, 
        'subtotal': base_amount,
        'discount': discount_amount,
        'total_to_pay': final_amount
    })

@app.route('/activation_form')
@login_required
def activation_form():
    clients = client_model.get_all()
    return render_template('activation.html', clients=clients, user=session)

@app.route('/api/activation/create', methods=['POST'])
@login_required
def create_activation():
    data = request.get_json()
    client_id = data.get('client_id')
    phone_number = data.get('phone_number')
    tariff_name = data.get('tariff_name', 'Безлимитный Плюс')
    
    if not client_id or not phone_number:
        return jsonify({'success': False, 'error': 'Укажите клиента и активируемый номер телефона'})
    
    sale_model.add_activation(client_id, phone_number, tariff_name, session['user_id'])
    return jsonify({'success': True})

@app.route('/payment_form')
@login_required
def payment_form():
    clients = client_model.get_all()
    return render_template('payment.html', clients=clients, user=session)

@app.route('/api/payment/make', methods=['POST'])
@login_required
def make_payment():
    data = request.get_json()
    client_id = data.get('client_id')
    amount = data.get('amount')
    
    if not client_id or not amount:
        return jsonify({'success': False, 'error': 'Введите корректную сумму платежа'})
    
    # ИСПРАВЛЕНО: Безопасная проверка числового формата перед сравнением
    try:
        amount_val = float(amount)
    except (ValueError, TypeError):
        return jsonify({'success': False, 'error': 'Сумма платежа должна быть числом'})
        
    if amount_val <= 0:
        return jsonify({'success': False, 'error': 'Сумма должна быть больше нуля'})
    
    sale_model.add_direct_payment(client_id, amount_val, session['user_id'])
    return jsonify({'success': True})


# ==================== СТАТИСТИКА И ОТЧЁТЫ ПО ВЫРУЧКЕ ====================

@app.route('/reports')
@login_required
def reports():
    return render_template('reports.html', user=session)

@app.route('/api/reports/data')
@login_required
def reports_data():
    date_from = request.args.get('date_from', (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d'))
    date_to = request.args.get('date_to', datetime.now().strftime('%Y-%m-%d'))
    
    operations = sale_model.get_by_period(date_from, date_to)
    revenue = sale_model.get_revenue_by_period(date_from, date_to)
    
    type_names = {
        'activation': 'Активация SIM-карты', 
        'sale': 'Продажа товара', 
        'payment': 'Пополнение баланса'
    }
    
    for op in operations:
        op['type_name'] = type_names.get(op['type'], op['type'])
    
    return jsonify({
        'operations': operations,
        'revenue': revenue,
        'date_from': date_from,
        'date_to': date_to
    })


# ==================== СЛУЖЕБНЫЕ API СПИСКОВ ====================

@app.route('/api/clients')
@login_required
def api_clients():
    clients = client_model.get_all()
    return jsonify(clients)

@app.route('/api/products')
@login_required
def api_services():
    products = product_model.get_all()
    return jsonify(products)


if __name__ == '__main__':
    app.run(debug=True, port=5000)
